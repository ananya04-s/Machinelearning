# Student Performance Prediction

This is a Google Colab-ready starter project.

## Steps
1. Open the notebook in Google Colab.
2. Upload the dataset (or replace with your own).
3. Run cells from top to bottom.
4. Train the model and evaluate results.

Suggested libraries:
- pandas
- numpy
- scikit-learn
- matplotlib
