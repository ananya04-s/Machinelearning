# Titanic_Survival_Prediction
Run the notebook in Google Colab.