# Heart_Disease_Prediction
Run the notebook in Google Colab.