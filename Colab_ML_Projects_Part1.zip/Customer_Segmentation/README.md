# Customer_Segmentation
Run the notebook in Google Colab.