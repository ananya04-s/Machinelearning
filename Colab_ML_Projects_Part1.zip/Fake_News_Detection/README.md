# Fake_News_Detection
Run the notebook in Google Colab.