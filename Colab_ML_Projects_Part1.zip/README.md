# Google Colab Machine Learning Projects
Open each .ipynb in Google Colab and Run All.